OpenGFX BigGUI
--------------

Contents:

1 About
2 Usage and Parameters
3 Obtaining the source
4 Credits
5 License



-------
1 About
-------

OpenGFX BigGUI provides sprites for the GUI which are twice the size
    of the default GUI sprites.

Name of this Repo:  OpenGFX BigGUI
Repository version: 19



----------------------
2 Usage and Parameters
----------------------

Just add the NewGRF to your NewGRF list.
Alternatively you can add it to the list of static NewGRFs within your
openttd.cfg. Consult the OpenTTD readme on where your config file is
found

This NewGRF has one parameter which determines the size of the sprites used
for the GUI.



------------------------
3 Obtaining the source
------------------------

The source code can be obtained from the #openttdcoop DevZone at
    http://dev.openttdcoop.org/projects/ogfx-biggui
or via mercurial checkout
    hg clone http://hg.openttdcoop.org/ogfx-biggui



---------
4 Credits
---------

Programming: planetmaker
Graphics:    Zephyris (2x zoom)
             Yoshi (1.5x zoom, some 2x zoom)

Special thanks to #openttdcoop and especially Ammler who provides and
works a lot on maintaining the Development Zone where this repository is
hosted and who also frequently gives much valuable input. Thanks also to
Alberth, Terkhen Yexo, Rubidium and Ammler who frequently give valuable
input in form of advice and patches to this project. Last but not least
thanks to all the NewGRF authors whose NewGRFs can be my playground for
this project.



---------------
5 License
---------------

OpenGFX BigGUI
Copyright (C) 2011-2012 planetmaker, Zephyris and Yoshi

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this NewGRF; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
